# Tradebot setup — your one-time steps (~45 min)

You do these once. After that, your only recurring job is one tap each weekday morning (Zerodha login link on Telegram).

## 1. Telegram bot (5 min) — how the bot talks to you
1. In Telegram, open **@BotFather** → send `/newbot` → pick a name (e.g. `Mudit Tradebot`) and a username ending in `bot`.
2. Copy the **token** it gives you.
3. Open your new bot and send it "hi".
4. In a browser open `https://api.telegram.org/bot<TOKEN>/getUpdates` → find `"chat":{"id":123456789` → that number is your **chat ID**.

## 2. Zerodha Kite developer app (10 min)
1. Go to **developers.kite.trade** → sign up / log in with your Zerodha ID.
2. **Create new app** → type **Personal** (free). Price data comes free from Yahoo Finance.
3. Redirect URL: put `http://127.0.0.1` for now (we change it in step 5).
4. Copy the **API key** and **API secret**. Treat the secret like a password.

## 3. GitHub (5 min) — how I ship code to the server and read results
1. Create a free account at github.com if you don't have one.
2. Create a **private** repo named `tradebot` (empty, no README).
3. In claude.ai → Settings → Connectors, **connect GitHub**. Tell me the repo name and I'll push the code.

## 4. AWS Lightsail server (15 min, ~$5/month)
1. lightsail.aws.amazon.com → **Create instance** → Region **Mumbai (ap-south-1)** → Linux → **OS Only → Ubuntu 24.04** → $5 plan → Create.
2. **Networking → Create static IP** → attach to the instance.
3. Instance → **Networking → IPv4 firewall → Add rule**: Custom TCP, port **8000**.
4. Click **Connect using SSH** (opens a terminal in your browser) and paste:
   ```
   ssh-keygen -t ed25519 -N "" -f ~/.ssh/id_ed25519 && cat ~/.ssh/id_ed25519.pub
   ```
5. Copy the line it prints → GitHub repo → **Settings → Deploy keys → Add** → paste → tick **Allow write access**.
6. Back in the terminal:
   ```
   ssh-keyscan github.com >> ~/.ssh/known_hosts
   git clone git@github.com:<your-github-username>/tradebot.git && cd tradebot
   git config user.name tradebot && git config user.email tradebot@localhost
   bash setup_server.sh
   nano .env        # paste Kite key+secret, Telegram token+chat ID; Ctrl+O, Enter, Ctrl+X
   bash setup_server.sh
   ```

## 5. Finish (2 min)
1. The script prints a URL like `http://13.x.x.x:8000/kite/callback`. Paste it as the **Redirect URL** in your Kite app.
2. In the terminal: `.venv/bin/python run.py ping` → tap the Telegram link → log in.
3. Setup already started downloading 12 years of data and running both backtests — reports arrive on Telegram.

## Daily (30 sec)
8:15 AM IST weekdays: Telegram link → log in to Zerodha → done.

## Safety rules built in
- Live trading is **off** until you set `LIVE_ENABLED=true` in `.env` yourself.
- Money limits (`MAX_LIVE_CAPITAL_INR`, daily/monthly loss caps) live only in `.env` on your server — I can change strategy code, never your limits.
- Your API secret and 2FA never leave the server; I never see them.
