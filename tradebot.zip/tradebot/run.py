#!/usr/bin/env python3
"""Single entry point.

  python run.py universe          # download Nifty 100 list
  python run.py fetch             # pull daily history from Kite (needs today's login)
  python run.py backtest          # Phase 0 on real data -> reports/phase0_report.html
  python run.py backtest --synthetic   # same pipeline on fake data (testing)
  python run.py serve             # Kite login callback server (runs as a service)
  python run.py ping              # morning Telegram login link
"""
import argparse
import os
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))


def load_env():
    f = ROOT / ".env"
    if f.exists():
        for line in f.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())


def merge(base: dict, over: dict) -> dict:
    out = dict(base)
    for k, v in over.items():
        out[k] = merge(out[k], v) if isinstance(v, dict) and isinstance(out.get(k), dict) else v
    return out


def profile_cfg(cfg: dict, profile: str) -> dict:
    over = cfg.get("profiles", {}).get(profile, {})
    return merge({k: v for k, v in cfg.items() if k != "profiles"}, over)


def cmd_backtest(cfg, synthetic: bool, profile: str):
    from tradebot import backtest, data, evaluate, notify
    from tradebot.costs import CostModel
    from tradebot.strategies import REGISTRY

    bt = cfg["backtest"]
    if synthetic:
        ddir = ROOT / "data" / "synthetic"
        symbols = data.make_synthetic(ddir, n=60 if cfg["universe"] == "nifty100" else 200,
                                      benchmark=cfg["benchmark"])
    else:
        ddir = data.DAILY_DIR
        symbols = data.load_universe(cfg["universe"])
    panel = data.load_panel(symbols, cfg["benchmark"], ddir, bt["start"], bt["end"])
    costs = CostModel.from_config(cfg["costs"])
    idx = panel["close"].index
    oos_start = idx[int(len(idx) * (1 - bt["oos_fraction"]))]
    benches = evaluate.benchmarks(panel, idx)
    bench_eq = benches["Nifty ETF (buy & hold)"]

    results, curves = [], dict(benches)
    for name, spec in cfg["strategies"].items():
        if not spec:
            continue
        fn = REGISTRY[name]
        res = backtest.run(panel, fn(panel, **spec["params"]), costs,
                           bt["initial_capital"], bt["max_positions"])
        pert = [backtest.run(panel, fn(panel, **{**spec["params"], **p}), costs,
                             bt["initial_capital"], bt["max_positions"])
                for p in spec.get("perturb", [])]
        r = evaluate.check_gates(name, res, pert, bench_eq, cfg["gates"], oos_start, bt["risk_free"])
        results.append(r)
        curves[name] = res.equity
        out_dir = ROOT / "reports" / profile
        out_dir.mkdir(parents=True, exist_ok=True)
        res.trades.to_csv(out_dir / f"trades_{name}.csv", index=False)
        print(f"{name:16s} CAGR {r['metrics']['cagr']:+.1%}  DD {r['metrics']['max_dd']:+.1%}  "
              f"trades {r['trades']:4d}  {'PASS' if r['passed'] else 'FAIL'}")
    bm = evaluate.metrics(bench_eq)
    print(f"{'Nifty ETF':16s} CAGR {bm['cagr']:+.1%}  DD {bm['max_dd']:+.1%}")

    title = (f"Phase 0 backtest — {profile.upper()} profile — {cfg['universe']} — "
             + ("SYNTHETIC test data" if synthetic else "real data"))
    out = evaluate.write_report(results, curves, ROOT / "reports" / profile, title,
                                panel["warnings"], synthetic)
    print("Report:", out)
    if not synthetic:
        passed = [r["name"] for r in results if r["passed"]] or ["none"]
        notify.send_file(out, caption=f"Phase 0 ({profile}) done. Passed: {', '.join(passed)}")


def main():
    load_env()
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["universe", "fetch", "backtest", "serve", "ping",
                                    "bootstrap", "publish"])
    ap.add_argument("--synthetic", action="store_true")
    ap.add_argument("--source", default="yahoo", choices=["yahoo", "kite"])
    ap.add_argument("--profile", default="all", help="conservative | aggressive | all")
    a = ap.parse_args()
    cfg = yaml.safe_load((ROOT / "config.yaml").read_text())
    (ROOT / "reports").mkdir(exist_ok=True)

    if a.cmd == "universe":
        from tradebot import data
        for idx in data.INDEX_URLS:
            print(idx, len(data.refresh_universe(idx)), "symbols saved")
    elif a.cmd == "fetch":
        from tradebot import data, notify
        syms = sorted(set(data.load_universe("nifty100")) | set(data.load_universe("nifty500")))
        if a.source == "kite":  # needs paid Connect plan + today's login
            from tradebot import kite_auth
            failed = data.fetch_kite_history(kite_auth.get_kite(), syms + [cfg["benchmark"]])
        else:
            failed = data.fetch_yahoo_history(syms + [cfg["benchmark"]])
        msg = f"Data fetch done: {len(syms) - len(failed)}/{len(syms)} symbols."
        if failed:
            msg += f" Missing: {', '.join(failed)}"
        print(msg); notify.send(msg)
    elif a.cmd == "backtest":
        profiles = ["conservative", "aggressive"] if a.profile == "all" else [a.profile]
        for p in profiles:
            print(f"\n=== {p} ===")
            cmd_backtest(profile_cfg(cfg, p), a.synthetic, p)
    elif a.cmd == "serve":
        from tradebot import kite_auth
        kite_auth.serve()
    elif a.cmd == "ping":
        from tradebot import kite_auth
        kite_auth.morning_ping()
    elif a.cmd == "bootstrap":  # first run after first login: data -> backtest -> publish
        import subprocess
        from tradebot import notify
        notify.send("📥 Downloading 12 years of NSE data and running both backtests. "
                    "Reports arrive here in ~20-30 min.")
        py = [sys.executable, str(ROOT / "run.py")]
        for step in ("universe", "fetch", "backtest", "publish"):
            subprocess.run(py + [step], cwd=ROOT, check=False)
    elif a.cmd == "publish":  # push reports to GitHub so Claude can review them
        import subprocess
        if not (ROOT / ".git").exists():
            print("no git repo; skipping publish")
            return
        sh = lambda *c: subprocess.run(list(c), cwd=ROOT, check=False)
        sh("git", "add", "-f", "reports/")
        sh("git", "commit", "-m", "reports: automated update")
        sh("git", "pull", "--rebase", "--autostash")
        sh("git", "push")


if __name__ == "__main__":
    main()
