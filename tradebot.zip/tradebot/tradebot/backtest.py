"""Daily portfolio simulator. Signals at close of t -> orders filled at open of t+1."""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from .costs import CostModel


@dataclass
class Result:
    equity: pd.Series
    trades: pd.DataFrame
    total_costs: float
    exposure: pd.Series = field(default=None)


def run(panel: dict, signals: dict, costs: CostModel, capital: float,
        max_positions: int) -> Result:
    o = panel["open"].to_numpy(float)
    c = panel["close"].to_numpy(float)
    dates = panel["close"].index
    syms = list(panel["close"].columns)
    entry = signals["entry"].reindex_like(panel["close"]).fillna(False).to_numpy(bool)
    exit_ = signals["exit"].reindex_like(panel["close"]).fillna(False).to_numpy(bool)
    score = signals["score"].reindex_like(panel["close"]).to_numpy(float)
    atr = signals.get("atr")
    atr = atr.reindex_like(panel["close"]).to_numpy(float) if atr is not None else None
    atr_mult = signals.get("atr_mult")
    max_hold = signals.get("max_hold")

    cash = capital
    pos = {}  # j -> dict(shares, entry_px, entry_i, peak, cost_in)
    equity = np.empty(len(dates))
    exposure = np.empty(len(dates))
    trades, total_costs = [], 0.0
    last_px = np.full(len(syms), np.nan)

    for i in range(len(dates)):
        # ---- 1. execute orders decided at close of i-1, at today's open
        if i > 0:
            p = i - 1
            sells = []
            for j, ps in pos.items():
                stop_hit = False
                if atr is not None and atr_mult and not math.isnan(atr[p, j]):
                    stop_hit = c[p, j] < ps["peak"] - atr_mult * atr[p, j]
                timed_out = max_hold is not None and (p - ps["entry_i"]) >= max_hold
                if exit_[p, j] or stop_hit or timed_out:
                    sells.append(j)
            for j in sells:
                if math.isnan(o[i, j]):
                    continue  # no trade today (halt/holiday for symbol): retry tomorrow
                ps = pos.pop(j)
                px = costs.sell_price(o[i, j])
                value = ps["shares"] * px
                fee = costs.sell_cost(value)
                cash += value - fee
                total_costs += fee
                trades.append({
                    "symbol": syms[j], "entry_date": dates[ps["entry_i"] + 1], "exit_date": dates[i],
                    "shares": ps["shares"], "entry_px": ps["entry_px"], "exit_px": px,
                    "pnl": value - fee - ps["cost_in"],
                    "ret": (value - fee) / ps["cost_in"] - 1,
                    "days": (dates[i] - dates[ps["entry_i"] + 1]).days,
                })
            free = max_positions - len(pos)
            if free > 0:
                cand = [j for j in np.flatnonzero(entry[p]) if j not in pos and not math.isnan(o[i, j])]
                cand.sort(key=lambda j: -np.nan_to_num(score[p, j], nan=-1e18))
                eq_prev = equity[p]
                target = eq_prev / max_positions
                for j in cand[:free]:
                    px = costs.buy_price(o[i, j])
                    shares = int(min(target, cash) // (px * (1 + 0.0013)))
                    if shares <= 0:
                        continue
                    value = shares * px
                    fee = costs.buy_cost(value)
                    if value + fee > cash:
                        continue
                    cash -= value + fee
                    total_costs += fee
                    pos[j] = {"shares": shares, "entry_px": px, "entry_i": p,
                              "peak": c[i, j] if not math.isnan(c[i, j]) else px,
                              "cost_in": value + fee}
        # ---- 2. mark to market at close
        valid = ~np.isnan(c[i])
        last_px[valid] = c[i, valid]
        mv = 0.0
        for j, ps in pos.items():
            if not math.isnan(c[i, j]):
                ps["peak"] = max(ps["peak"], c[i, j])
            mv += ps["shares"] * last_px[j]
        equity[i] = cash + mv
        exposure[i] = mv / equity[i] if equity[i] > 0 else 0

    return Result(pd.Series(equity, index=dates), pd.DataFrame(trades), total_costs,
                  pd.Series(exposure, index=dates))
