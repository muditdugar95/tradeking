"""Zerodha equity-delivery transaction cost model."""
from dataclasses import dataclass


@dataclass
class CostModel:
    brokerage: float = 0.0
    stt: float = 0.001
    exchange: float = 0.0000297
    sebi: float = 0.000001
    stamp_buy: float = 0.00015
    gst: float = 0.18
    dp_per_sell: float = 15.34
    slippage: float = 0.001

    @classmethod
    def from_config(cls, cfg: dict) -> "CostModel":
        return cls(**{k: float(v) for k, v in cfg.items()})

    def _common(self, value: float) -> float:
        taxable = self.brokerage * value + self.exchange * value + self.sebi * value
        return self.stt * value + taxable * (1 + self.gst)

    def buy_cost(self, value: float) -> float:
        return self._common(value) + self.stamp_buy * value

    def sell_cost(self, value: float) -> float:
        return self._common(value) + self.dp_per_sell

    def buy_price(self, open_px: float) -> float:
        return open_px * (1 + self.slippage)

    def sell_price(self, open_px: float) -> float:
        return open_px * (1 - self.slippage)
