"""Rule-based strategies. Each returns signal frames (dates x symbols) computed at the
CLOSE of day t; the engine executes them at the OPEN of day t+1 (no look-ahead).

Returned dict:
  entry  : bool  - eligible to buy
  exit   : bool  - must sell if held
  score  : float - ranking when more entries than free slots (higher = better)
  atr    : float - ATR for trailing stops (optional)
  atr_mult, max_hold : scalars (optional)
"""
from __future__ import annotations

import numpy as np
import pandas as pd


# ---------------------------------------------------------------- indicators
def sma(df, n):
    return df.rolling(n, min_periods=n).mean()


def atr(high, low, close, n=14):
    prev = close.shift(1)
    tr = pd.concat([(high - low), (high - prev).abs(), (low - prev).abs()]).groupby(level=0).max()
    tr = tr.reindex(close.index)
    return tr.rolling(n, min_periods=n).mean()


def rsi(close, n):
    d = close.diff()
    up = d.clip(lower=0).ewm(alpha=1 / n, adjust=False, min_periods=n).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False, min_periods=n).mean()
    return 100 - 100 / (1 + up / dn.replace(0, np.nan))


def regime_ok(bench_close: pd.Series, index) -> pd.Series:
    """Market regime: benchmark above its 200-day average."""
    b = bench_close.reindex(index).ffill()
    return b > b.rolling(200, min_periods=200).mean()


def _apply_regime(entry, panel, on):
    if not on:
        return entry
    ok = regime_ok(panel["bench_close"], entry.index)
    return entry & ok.values[:, None]


# ---------------------------------------------------------------- strategies
def momentum_12_1(panel, lookback=252, skip=21, top_n=8, trend_sma=200, regime_filter=True):
    """Monthly rotation into the top-N stocks by 12-month return excluding last month."""
    c = panel["close"]
    mom = c.shift(skip) / c.shift(lookback) - 1
    trend = c > sma(c, trend_sma)
    month = c.index.to_period("M")
    last_day = pd.Series(month, index=c.index) != pd.Series(month, index=c.index).shift(-1)
    rebal = last_day.values[:, None]
    ranked = mom.where(trend).rank(axis=1, ascending=False)
    in_top = ranked <= top_n
    entry = _apply_regime(in_top & rebal, panel, regime_filter)
    exit_ = (~in_top) & rebal
    if regime_filter:
        bad = ~regime_ok(panel["bench_close"], c.index)
        exit_ = exit_ | (bad.values[:, None] & rebal)
    return {"entry": entry.fillna(False), "exit": exit_.fillna(False), "score": mom}


def trend_follow(panel, fast=50, slow=200, breakout=20, atr_mult=3.0, regime_filter=True):
    """Buy fresh 20-day highs in stocks with 50 > 200 SMA; exit below 50 SMA or ATR trail."""
    c, h, l = panel["close"], panel["high"], panel["low"]
    f, s = sma(c, fast), sma(c, slow)
    hh = c.rolling(breakout, min_periods=breakout).max().shift(1)
    entry = (c > hh) & (f > s) & (c > f)
    entry = _apply_regime(entry, panel, regime_filter)
    exit_ = c < f
    score = c / c.shift(126) - 1
    return {"entry": entry.fillna(False), "exit": exit_.fillna(False), "score": score,
            "atr": atr(h, l, c), "atr_mult": atr_mult}


def donchian(panel, entry=55, exit=20, atr_mult=3.0, regime_filter=True):
    """Classic turtle-style channel breakout."""
    c, h, l = panel["close"], panel["high"], panel["low"]
    up = h.rolling(entry, min_periods=entry).max().shift(1)
    dn = l.rolling(exit, min_periods=exit).min().shift(1)
    a = atr(h, l, c)
    ent = _apply_regime(c > up, panel, regime_filter)
    score = (c - c.shift(entry)) / a  # volatility-adjusted strength
    return {"entry": ent.fillna(False), "exit": (c < dn).fillna(False), "score": score,
            "atr": a, "atr_mult": atr_mult}


def rsi2_reversion(panel, rsi_len=2, rsi_entry=10, trend_sma=200, exit_sma=5,
                   max_hold=10, regime_filter=False):
    """Buy short-term oversold dips in long-term uptrends; exit on bounce or time stop."""
    c = panel["close"]
    r = rsi(c, rsi_len)
    entry = (r < rsi_entry) & (c > sma(c, trend_sma))
    entry = _apply_regime(entry, panel, regime_filter)
    exit_ = c > sma(c, exit_sma)
    return {"entry": entry.fillna(False), "exit": exit_.fillna(False), "score": -r,
            "max_hold": max_hold}


REGISTRY = {
    "momentum_12_1": momentum_12_1,
    "trend_follow": trend_follow,
    "donchian": donchian,
    "rsi2_reversion": rsi2_reversion,
}
