"""Telegram notifications (login pings, alerts, reports)."""
import os
from pathlib import Path

import requests


def _cfg():
    return os.environ.get("TELEGRAM_BOT_TOKEN"), os.environ.get("TELEGRAM_CHAT_ID")


def send(text: str) -> bool:
    token, chat = _cfg()
    if not token or not chat:
        print("[notify] Telegram not configured:\n" + text)
        return False
    r = requests.post(f"https://api.telegram.org/bot{token}/sendMessage",
                      data={"chat_id": chat, "text": text, "disable_web_page_preview": True},
                      timeout=20)
    return r.ok


def send_file(path: Path, caption: str = "") -> bool:
    token, chat = _cfg()
    if not token or not chat:
        print(f"[notify] would send {path}")
        return False
    with open(path, "rb") as f:
        r = requests.post(f"https://api.telegram.org/bot{token}/sendDocument",
                          data={"chat_id": chat, "caption": caption},
                          files={"document": f}, timeout=60)
    return r.ok
