"""Daily Kite login.

Kite access tokens expire every morning (~6 AM IST) and need a human login with 2FA.
Flow: 8:15 AM the server sends you a Telegram link -> you log in on your phone ->
Zerodha redirects to this server's /kite/callback -> the token is saved for the day.
The API secret never leaves the server, so the redirect itself is harmless if seen.
"""
from __future__ import annotations

import datetime as dt
import json
import os
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from . import notify

ROOT = Path(__file__).resolve().parent.parent
TOKEN_FILE = ROOT / "state" / "access_token.json"
IST = dt.timezone(dt.timedelta(hours=5, minutes=30))


def _session_date(now: dt.datetime) -> dt.date:
    """Tokens roll over at 6 AM IST."""
    return (now - dt.timedelta(hours=6)).date()


def login_url() -> str:
    return f"https://kite.zerodha.com/connect/login?v=3&api_key={os.environ['KITE_API_KEY']}"


def token_valid() -> bool:
    if not TOKEN_FILE.exists():
        return False
    d = json.loads(TOKEN_FILE.read_text())
    return d.get("session") == str(_session_date(dt.datetime.now(IST)))


def get_kite():
    from kiteconnect import KiteConnect

    if not token_valid():
        raise RuntimeError("No valid Kite session today. Log in via the Telegram link.")
    kite = KiteConnect(api_key=os.environ["KITE_API_KEY"])
    kite.set_access_token(json.loads(TOKEN_FILE.read_text())["access_token"])
    return kite


def exchange_token(request_token: str) -> str:
    from kiteconnect import KiteConnect

    kite = KiteConnect(api_key=os.environ["KITE_API_KEY"])
    data = kite.generate_session(request_token, api_secret=os.environ["KITE_API_SECRET"])
    TOKEN_FILE.parent.mkdir(parents=True, exist_ok=True)
    TOKEN_FILE.write_text(json.dumps({
        "access_token": data["access_token"],
        "session": str(_session_date(dt.datetime.now(IST))),
        "user": data.get("user_id"),
    }))
    os.chmod(TOKEN_FILE, 0o600)
    return data.get("user_id", "")


def morning_ping():
    if token_valid():
        return
    notify.send("🔑 Good morning. Tap to log in to Zerodha for today's session:\n" + login_url())


class _Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        u = urlparse(self.path)
        if u.path != "/kite/callback":
            self.send_response(404); self.end_headers(); return
        q = parse_qs(u.query)
        try:
            if q.get("status", [""])[0] != "success":
                raise ValueError("login not successful")
            user = exchange_token(q["request_token"][0])
            msg, code = f"Logged in ({user}). The bot is live for today. You can close this tab.", 200
            notify.send("✅ Zerodha session active for today.")
        except Exception as e:  # noqa: BLE001
            msg, code = f"Login failed: {e}", 500
            notify.send(f"⚠️ Zerodha login failed: {e}")
        self.send_response(code)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.end_headers()
        self.wfile.write(msg.encode())

    def log_message(self, *a):
        pass


def serve(port: int | None = None):
    port = port or int(os.environ.get("CALLBACK_PORT", 8000))
    print(f"Kite callback listening on :{port}/kite/callback")
    HTTPServer(("127.0.0.1", port), _Handler).serve_forever()
