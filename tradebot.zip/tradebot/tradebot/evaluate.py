"""Metrics, pass/fail gates and the HTML report."""
from __future__ import annotations

import base64
import io
import json
from pathlib import Path

import numpy as np
import pandas as pd


def metrics(eq: pd.Series, rf: float = 0.065) -> dict:
    eq = eq.dropna()
    eq = eq[eq > 0]
    if len(eq) < 2:
        return {"cagr": np.nan, "vol": np.nan, "sharpe": np.nan, "max_dd": np.nan}
    yrs = (eq.index[-1] - eq.index[0]).days / 365.25
    r = eq.pct_change().dropna()
    cagr = (eq.iloc[-1] / eq.iloc[0]) ** (1 / yrs) - 1 if yrs > 0 else np.nan
    vol = r.std() * np.sqrt(252)
    sharpe = (r.mean() * 252 - rf) / vol if vol > 0 else np.nan
    dd = (eq / eq.cummax() - 1).min()
    return {"cagr": cagr, "vol": vol, "sharpe": sharpe, "max_dd": dd,
            "calmar": cagr / abs(dd) if dd < 0 else np.nan}


def yearly(eq: pd.Series) -> pd.Series:
    y = eq.resample("YE").last()
    first = eq.iloc[0]
    return y.pct_change().fillna(y.iloc[0] / first - 1)


def benchmarks(panel: dict, index) -> dict:
    b = panel["bench_close"].reindex(index).ffill()
    rets = panel["close"].reindex(index).pct_change(fill_method=None)
    ew = (1 + rets.mean(axis=1, skipna=True).fillna(0)).cumprod()
    return {"Nifty ETF (buy & hold)": b / b.dropna().iloc[0],
            "Equal-weight universe": ew / ew.iloc[0]}


def check_gates(name, res, perturbed, bench_eq, cfg_gates, oos_start, rf):
    eq = res.equity
    m, bm = metrics(eq, rf), metrics(bench_eq, rf)
    m_oos, bm_oos = metrics(eq.loc[oos_start:], rf), metrics(bench_eq.loc[oos_start:], rf)
    ys, yb = yearly(eq), yearly(bench_eq.reindex(eq.index).ffill())
    win = float((ys > yb).mean())
    n_trades = len(res.trades)
    pert_ok = all(metrics(p.equity, rf)["cagr"] > bm["cagr"] for p in perturbed)
    gates = {
        f"Beats Nifty by {cfg_gates['min_excess_cagr']:.0%}/yr after costs":
            m["cagr"] - bm["cagr"] >= cfg_gates["min_excess_cagr"],
        "Drawdown no worse than Nifty +5pp":
            m["max_dd"] >= bm["max_dd"] - cfg_gates["max_dd_slack"],
        "Beats Nifty on unseen recent data (out-of-sample)":
            m_oos["cagr"] > bm_oos["cagr"],
        f"Beats Nifty in >= {cfg_gates['min_year_win_rate']:.0%} of years":
            win >= cfg_gates["min_year_win_rate"],
        "Still beats Nifty with tweaked parameters": pert_ok,
        f">= {cfg_gates['min_trades']} trades (enough evidence)":
            n_trades >= cfg_gates["min_trades"],
    }
    t = res.trades
    return {
        "name": name, "metrics": m, "oos": m_oos, "bench": bm, "bench_oos": bm_oos,
        "year_win_rate": win, "trades": n_trades,
        "win_rate": float((t["pnl"] > 0).mean()) if n_trades else np.nan,
        "avg_hold_days": float(t["days"].mean()) if n_trades else np.nan,
        "total_costs": res.total_costs,
        "avg_exposure": float(res.exposure.mean()),
        "gates": gates, "passed": all(gates.values()),
        "yearly": {str(k.year): float(v) for k, v in ys.items()},
        "bench_yearly": {str(k.year): float(v) for k, v in yb.items()},
    }


# ---------------------------------------------------------------- report
def _png(fig) -> str:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=110, bbox_inches="tight")
    return base64.b64encode(buf.getvalue()).decode()


def write_report(results: list[dict], curves: dict, out_dir: Path, title: str,
                 warnings: list[str], synthetic: bool):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "phase0_results.json").write_text(json.dumps(results, indent=2, default=float))

    fig, ax = plt.subplots(2, 1, figsize=(10, 7), sharex=True,
                           gridspec_kw={"height_ratios": [3, 1.3]})
    for n, s in curves.items():
        s = s / s.dropna().iloc[0]
        bench = n.startswith("Nifty") or n.startswith("Equal")
        ax[0].plot(s.index, s, lw=1.1 if bench else 1.6,
                   ls="--" if bench else "-", label=n, color="#888" if n.startswith("Nifty") else None)
        ax[1].plot(s.index, s / s.cummax() - 1, lw=0.9, ls="--" if bench else "-")
    ax[0].set_yscale("log"); ax[0].set_ylabel("Growth of 1 (log)"); ax[0].legend(fontsize=8)
    ax[1].set_ylabel("Drawdown")
    for a in ax:
        a.grid(alpha=0.25); a.spines[["top", "right"]].set_visible(False)
    chart = _png(fig)
    plt.close(fig)

    def pct(x):
        return "–" if x is None or (isinstance(x, float) and np.isnan(x)) else f"{x:+.1%}"

    rows = ""
    for r in results:
        m, b = r["metrics"], r["bench"]
        badge = '<b style="color:#1a7f37">PASS</b>' if r["passed"] else '<b style="color:#c62828">FAIL</b>'
        gates = "".join(f"<li>{'✅' if ok else '❌'} {g}</li>" for g, ok in r["gates"].items())
        rows += f"""<tr><td><b>{r['name']}</b><br>{badge}</td>
<td>{pct(m['cagr'])}<br><small>Nifty {pct(b['cagr'])}</small></td>
<td>{pct(m['max_dd'])}<br><small>Nifty {pct(b['max_dd'])}</small></td>
<td>{m['sharpe']:.2f}</td><td>{pct(r['oos']['cagr'])}<br><small>Nifty {pct(r['bench_oos']['cagr'])}</small></td>
<td>{r['trades']}<br><small>win {r['win_rate']:.0%}, ~{r['avg_hold_days']:.0f}d hold</small></td>
<td>₹{r['total_costs']:,.0f}</td><td><ul>{gates}</ul></td></tr>"""

    years = sorted({y for r in results for y in r["yearly"]})
    yr_head = "".join(f"<th>{y}</th>" for y in years)
    first = results[0]
    yr_rows = "<tr><td>Nifty ETF</td>" + "".join(
        f"<td>{pct(first['bench_yearly'].get(y))}</td>" for y in years) + "</tr>"
    for r in results:
        yr_rows += f"<tr><td>{r['name']}</td>" + "".join(
            f"<td>{pct(r['yearly'].get(y))}</td>" for y in years) + "</tr>"

    banner = ('<div style="background:#fff3cd;padding:10px;border-radius:6px"><b>SYNTHETIC DATA TEST.</b> '
              'These numbers only prove the code works. They say nothing about real markets.</div>'
              if synthetic else "")
    warn = ("<h3>Data warnings (possible unadjusted splits — review)</h3><pre>" +
            "\n".join(warnings[:50]) + "</pre>") if warnings else ""
    passed = [r["name"] for r in results if r["passed"]]
    verdict = (f"<p><b>Passed all gates:</b> {', '.join(passed)}. Eligible for paper trading.</p>" if passed
               else "<p><b>No strategy passed all gates.</b> Nothing goes to paper trading yet.</p>")
    html = f"""<!doctype html><html><head><meta charset="utf-8"><title>{title}</title>
<style>body{{font-family:system-ui,sans-serif;max-width:1100px;margin:24px auto;padding:0 16px;color:#222}}
table{{border-collapse:collapse;width:100%;font-size:13px}}td,th{{border-bottom:1px solid #eee;padding:6px;vertical-align:top;text-align:left}}
ul{{margin:0;padding-left:16px}}small{{color:#777}}</style></head><body>
<h1>{title}</h1>{banner}{verdict}
<img src="data:image/png;base64,{chart}" style="width:100%">
<h2>Strategies vs gates</h2>
<table><tr><th>Strategy</th><th>CAGR</th><th>Max drawdown</th><th>Sharpe</th><th>Out-of-sample CAGR</th>
<th>Trades</th><th>Total costs</th><th>Gates</th></tr>{rows}</table>
<h2>Calendar-year returns</h2><div style="overflow-x:auto"><table><tr><th></th>{yr_head}</tr>{yr_rows}</table></div>
<p><small>Caveat: the universe is today's Nifty 100, so stocks that dropped out are missing (survivorship bias) —
this flatters every strategy. The equal-weight universe line carries the same bias; a strategy that can't beat it
isn't adding anything.</small></p>{warn}</body></html>"""
    (out_dir / "phase0_report.html").write_text(html)
    return out_dir / "phase0_report.html"
