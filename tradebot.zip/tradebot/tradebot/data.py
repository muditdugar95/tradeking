"""Market data: Kite historical fetch, local CSV cache, synthetic data for testing."""
from __future__ import annotations

import datetime as dt
import io
import time
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
DAILY_DIR = DATA_DIR / "daily"
INDEX_URLS = {
    "nifty100": "https://www.niftyindices.com/IndexConstituent/ind_nifty100list.csv",
    "nifty500": "https://www.niftyindices.com/IndexConstituent/ind_nifty500list.csv",
}
FIELDS = ["open", "high", "low", "close", "volume"]


# ---------------------------------------------------------------- universe
def universe_file(index: str) -> Path:
    return DATA_DIR / f"universe_{index}.csv"


def refresh_universe(index: str = "nifty100") -> list[str]:
    """Download current index constituents to data/universe_<index>.csv."""
    import requests

    r = requests.get(INDEX_URLS[index], headers={"User-Agent": "Mozilla/5.0"}, timeout=30)
    r.raise_for_status()
    df = pd.read_csv(io.StringIO(r.text))
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    df[["Symbol"]].to_csv(universe_file(index), index=False)
    return df["Symbol"].tolist()


def load_universe(index: str = "nifty100") -> list[str]:
    f = universe_file(index)
    if not f.exists():
        raise FileNotFoundError(f"{f} missing. Run: python run.py universe")
    return pd.read_csv(f)["Symbol"].dropna().astype(str).tolist()


# ---------------------------------------------------------------- yahoo fetch (free)
def fetch_yahoo_history(symbols: list[str], start: str = "2013-01-01",
                        out_dir: Path = DAILY_DIR) -> list[str]:
    """Free daily candles from Yahoo Finance (split/bonus adjusted). Returns failures."""
    import yfinance as yf

    out_dir.mkdir(parents=True, exist_ok=True)
    failed = []
    for i in range(0, len(symbols), 50):
        batch = symbols[i:i + 50]
        tickers = [f"{s}.NS" for s in batch]
        raw = None
        for attempt in range(3):
            try:
                raw = yf.download(tickers, start=start, auto_adjust=True, group_by="ticker",
                                  progress=False, threads=True)
                break
            except Exception:
                time.sleep(5 * (attempt + 1))
        for s, t in zip(batch, tickers):
            try:
                df = raw[t] if len(tickers) > 1 else raw
                df = df.rename(columns=str.lower)[FIELDS].dropna(subset=["close"])
                if len(df) < 50:
                    raise ValueError("too little data")
                df.index = pd.to_datetime(df.index).tz_localize(None).normalize()
                df.index.name = "date"
                df.to_csv(out_dir / f"{s}.csv")
            except Exception:
                failed.append(s)
        time.sleep(2)
    return failed


# ---------------------------------------------------------------- kite fetch
def fetch_kite_history(kite, symbols: list[str], start: str = "2013-01-01",
                       end: str | None = None, out_dir: Path = DAILY_DIR) -> list[str]:
    """Fetch daily candles from Kite (needs the paid Connect plan). Returns failures."""
    out_dir.mkdir(parents=True, exist_ok=True)
    tokens = {i["tradingsymbol"]: i["instrument_token"]
              for i in kite.instruments("NSE")}
    start_d = pd.Timestamp(start).date()
    end_d = pd.Timestamp(end).date() if end else dt.date.today()
    failed = []
    for sym in symbols:
        tok = tokens.get(sym)
        if tok is None:
            failed.append(sym)
            continue
        rows, cur = [], start_d
        while cur <= end_d:
            chunk_end = min(cur + dt.timedelta(days=1900), end_d)  # Kite: <=2000 days/request
            for attempt in range(3):
                try:
                    rows += kite.historical_data(tok, cur, chunk_end, "day")
                    break
                except Exception:
                    time.sleep(2 * (attempt + 1))
            else:
                failed.append(sym)
            time.sleep(0.35)  # stay under 3 req/s
            cur = chunk_end + dt.timedelta(days=1)
        if rows:
            df = pd.DataFrame(rows)
            df["date"] = pd.to_datetime(df["date"]).dt.tz_localize(None).dt.normalize()
            df = df.drop_duplicates("date").set_index("date")[FIELDS]
            df.to_csv(out_dir / f"{sym}.csv")
    return sorted(set(failed))


# ---------------------------------------------------------------- loading
def load_panel(symbols: list[str], benchmark: str, data_dir: Path = DAILY_DIR,
               start: str | None = None, end: str | None = None) -> dict:
    """Return {'open': df, 'high': df, ..., 'bench': series} with dates x symbols."""
    frames = {}
    for sym in set(symbols) | {benchmark}:
        f = data_dir / f"{sym}.csv"
        if f.exists():
            frames[sym] = pd.read_csv(f, parse_dates=["date"], index_col="date")
    if benchmark not in frames:
        raise FileNotFoundError(f"benchmark {benchmark} data missing in {data_dir}")
    panel = {}
    for fld in FIELDS:
        panel[fld] = pd.DataFrame({s: d[fld] for s, d in frames.items()}).sort_index()
    if start:
        panel = {k: v.loc[start:] for k, v in panel.items()}
    if end:
        panel = {k: v.loc[:end] for k, v in panel.items()}
    bench = {k: panel[k].pop(benchmark) for k in FIELDS}
    panel["bench_close"] = bench["close"]
    panel["warnings"] = sanity_check(panel["close"])
    return panel


def sanity_check(close: pd.DataFrame) -> list[str]:
    """Flag likely unadjusted splits/bonuses (one-day moves beyond -40%/+60%)."""
    rets = close.pct_change(fill_method=None)
    out = []
    for sym in close.columns:
        bad = rets[sym][(rets[sym] < -0.40) | (rets[sym] > 0.60)]
        for d, r in bad.items():
            out.append(f"{sym} {d.date()} {r:+.0%}")
    return out


# ---------------------------------------------------------------- synthetic
def make_synthetic(out_dir: Path, n: int = 60, benchmark: str = "NIFTYBEES",
                   start: str = "2013-01-01", end: str = "2026-10-30", seed: int = 7) -> list[str]:
    """Fake but realistic-ish price data so the pipeline can be tested without Kite.
    Results on this data mean NOTHING about real markets."""
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range(start, end)
    T = len(dates)
    mkt = rng.normal(0.0005, 0.011, T)
    crash = (dates >= "2020-02-20") & (dates <= "2020-03-24")
    mkt[crash] -= 0.018
    rec = (dates > "2020-03-24") & (dates <= "2020-08-31")
    mkt[rec] += 0.004
    bear22 = (dates >= "2022-01-15") & (dates <= "2022-06-20")
    mkt[bear22] -= 0.0015
    out_dir.mkdir(parents=True, exist_ok=True)
    syms = []
    for i in range(n):
        beta = rng.uniform(0.7, 1.3)
        drift = np.zeros(T)
        regime = rng.normal(0, 0.0006)
        for t in range(T):  # persistent idiosyncratic drift -> some momentum exists
            if t % 63 == 0:
                regime = 0.7 * regime + rng.normal(0, 0.0006)
            drift[t] = regime
        r = beta * mkt + drift + rng.normal(0, 0.016, T)
        listed = 0 if i < n * 0.85 else rng.integers(T // 4, T // 2)
        close = 100 * np.exp(np.cumsum(r))
        df = _ohlc(close, dates, rng)
        df.iloc[:listed] = np.nan
        sym = f"SYN{i:03d}"
        df.dropna().to_csv(out_dir / f"{sym}.csv", index_label="date")
        syms.append(sym)
    bclose = 100 * np.exp(np.cumsum(mkt + 0.0001))
    _ohlc(bclose, dates, rng, vol=0.004).to_csv(out_dir / f"{benchmark}.csv", index_label="date")
    return syms


def _ohlc(close, dates, rng, vol=0.008):
    prev = np.r_[close[0], close[:-1]]
    open_ = prev * (1 + rng.normal(0, vol / 2, len(close)))
    high = np.maximum(open_, close) * (1 + np.abs(rng.normal(0, vol, len(close))))
    low = np.minimum(open_, close) * (1 - np.abs(rng.normal(0, vol, len(close))))
    return pd.DataFrame({"open": open_, "high": high, "low": low, "close": close,
                         "volume": rng.integers(1e5, 5e6, len(close))}, index=dates)
