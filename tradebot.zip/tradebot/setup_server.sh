#!/usr/bin/env bash
# One-shot setup for a fresh Ubuntu 22.04/24.04 server (AWS Lightsail, Mumbai).
# Run from inside the tradebot folder:  bash setup_server.sh
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)"

echo "==> Timezone to IST"
sudo timedatectl set-timezone Asia/Kolkata

echo "==> System packages"
sudo apt-get update -y
sudo apt-get install -y python3-venv python3-pip git unzip caddy

echo "==> Python environment"
python3 -m venv "$DIR/.venv"
"$DIR/.venv/bin/pip" install -q --upgrade pip
"$DIR/.venv/bin/pip" install -q -r "$DIR/requirements.txt"

if [ ! -f "$DIR/.env" ]; then
  cp "$DIR/.env.example" "$DIR/.env"
  chmod 600 "$DIR/.env"
  echo "!! Fill in $DIR/.env (nano .env), then re-run this script."
  exit 0
fi

echo "==> Login callback service"
sudo tee /etc/systemd/system/tradebot-login.service >/dev/null <<EOF
[Unit]
Description=Tradebot Kite login callback
After=network-online.target
[Service]
WorkingDirectory=$DIR
ExecStart=$DIR/.venv/bin/python $DIR/run.py serve
Restart=always
User=$USER
[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable --now tradebot-login

echo "==> Scheduled jobs (IST)"
PY="$DIR/.venv/bin/python $DIR/run.py"
( crontab -l 2>/dev/null | grep -v tradebot ; cat <<EOF
15 8 * * 1-5 cd $DIR && $PY ping >> $DIR/logs/cron.log 2>&1 # tradebot
0 23 * * * cd $DIR && git pull --ff-only >> $DIR/logs/git.log 2>&1 # tradebot
EOF
) | crontab -
mkdir -p "$DIR/logs"

echo "==> First run: downloading data + running backtests in the background (~20 min)"
if ! ls "$DIR"/data/daily/*.csv >/dev/null 2>&1; then
  nohup "$DIR/.venv/bin/python" "$DIR/run.py" bootstrap >> "$DIR/logs/bootstrap.log" 2>&1 &
fi

IP=$(curl -s https://checkip.amazonaws.com)
HOST="$(echo "$IP" | tr . -).sslip.io"
echo "==> HTTPS for the Kite login (free certificate for $HOST)"
printf '%s {\n    reverse_proxy 127.0.0.1:8000\n}\n' "$HOST" | sudo tee /etc/caddy/Caddyfile >/dev/null
sudo systemctl restart caddy
sleep 8
echo
echo "Done. Set this as the Redirect URL in your Kite developer app:"
echo "    https://$HOST/kite/callback"
echo "Then test the login: $DIR/.venv/bin/python $DIR/run.py ping"
